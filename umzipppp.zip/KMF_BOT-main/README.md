![NEW](https://user-images.githubusercontent.com/58104674/123948552-26ed5100-d9bf-11eb-9a76-96dcda13d870.gif)
<h1 align="center">KMF BOT 2.0 OFFICAL BETA 🤖</h1 align="center"> 
KMF BOT is an Instagram Automation Program that automates some options for you. You can run the bot and it will start building real, organic 
followers to your account. You can get average 150-200 followers every day And Yet our BOT not violate any of Instagram's Limitation, so you don't have to worry about getting 
ACTION BLOCK !

For Help [JOIN TELEGRAM](https://t.me/ProjectX_insta) 😇

### ⚡Features

- TeamHunter
- Masslooker
- C-Mention
- Re-Hash
- Inshackle
- Like Hashtag
- HashLiker
- Bulk Group DM
- Like & Comment Hashtag
- Unfollow Non-Followers
---

# ⚙️How To Use

### Installation (Termux)
```
pkg install python
```
```
git clone https://github.com/ananthuganesh/KMF_BOT.git
```
```
cd KMF_BOT
```
```
pip install -r requirements.txt
```
```
python main.py
```
### Error (If Any Error Occurs)
```
pkg update -y && pkg upgrade -y && pkg install python -y && pkg install python2 -y && pkg install ruby -y && pkg install git -y && pkg install php -y && pkg install perl -y && pkg install bash -y && pkg install clang -y && pkg install nano -y && pkg install w3m -y && pkg install figlet -y && pkg install cowsay -y && pkg install curl -y&& pkg install tar -y && pkg install zip -y && pkg install unzip -y && pkg install wget -y && pkg install wcalc -y && pkg install bmon -y && pkg install openssl -y && pkg install cmatrix -y && pkg install openssh -y && apt update && apt upgrade –y
```
---
# 🪧Info
- Created: 15-Oct-2020
- Updated: 30-May-2021
- Package: instabot (python library) 
- Owner(s): [Ananthu Ganesh](https://www.instagram.com/un_f__amour/), [Arun](https://www.instagram.com/dr.luttappi/)
- Maintainer(s): [Anandhu](https://www.instagram.com/mind________freezer/)
---
# ⚠Warnings
This code is in no way affiliated with, authorized, maintained, sponsored or endorsed by Instagram, Facebook inc. or any of its affiliates or subsidiaries. This is an independent and unofficial API. Use it at your own risk.
